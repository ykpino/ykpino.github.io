// document.querySelector('.top_banner i').addEventListener('click',function(){
//     document.querySelector('.top_banner').style.display='none';
// })

//같은방식

// var bannerClose = function (){
//     document.querySelector('.top_banner').style.display='none';
// }   -----> 위로올려줘야 작동

// document.querySelector('.top_banner i').addEventListener('click', bannerClose);

// function bannerClose(){
//     document.querySelector('.top_banner').style.display='none';
// }

$(function(){
    $('.top_banner i').on('click', function(){
        // $('.top_banner').hide();
        $('.top_banner').slideUp();
    });

    $('.main_slider').slick({
        autoplay:true,
        dots:true,
        pauseOnHover:false,
        pauseOnFocus:false,
        
    });


})
