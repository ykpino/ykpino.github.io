$(function(){

    // $('.xi-bars').on('click', function(){
    //     $(this).hide();
    // });

    // document.querySelector('.xi-bars').addEventListener('click', ()=> {

    // })
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
}); //end